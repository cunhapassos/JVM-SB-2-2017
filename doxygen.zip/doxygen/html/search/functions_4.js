var searchData=
[
  ['pl_5fbuscaobjetoheap',['PL_buscaObjetoHeap',['../pilhas__listas_8h.html#ae14dfa5e83aae5e47d8cd52b525f1cc4',1,'pilhas_listas.c']]],
  ['pl_5fbuscarclasse',['PL_buscarClasse',['../pilhas__listas_8h.html#add36f4ad480b31c137d5155dd940d5f9',1,'pilhas_listas.c']]],
  ['pl_5finicializarpilha',['PL_inicializarPilha',['../pilhas__listas_8h.html#adc6eb89f6e9afcdbf16ad2178da7da2c',1,'pilhas_listas.c']]],
  ['pl_5finserirclassetopo',['PL_inserirClasseTopo',['../pilhas__listas_8h.html#ad90b1d019a954438448b4a2e829c7565',1,'pilhas_listas.c']]],
  ['pl_5fpilhavazia',['PL_pilhaVazia',['../pilhas__listas_8h.html#ab1bf62900b61ee44ca2ac8c7dc981103',1,'pilhas_listas.c']]],
  ['pl_5fpop',['PL_pop',['../pilhas__listas_8h.html#a6234448e6bf6c0678f34d24f463cb71d',1,'pilhas_listas.c']]],
  ['pl_5fpush',['PL_push',['../pilhas__listas_8h.html#a3467c45dbbd8ec3164aaea4d9a7727e1',1,'pilhas_listas.c']]],
  ['pl_5fremoverclassetopo',['PL_removerClasseTopo',['../pilhas__listas_8h.html#a1f26c4ce1cd24d119856e91b35e8cd3a',1,'pilhas_listas.c']]],
  ['pl_5ftopopilha',['PL_topoPilha',['../pilhas__listas_8h.html#ab6272f4e08e527ce95a0092039b08901',1,'pilhas_listas.c']]]
];

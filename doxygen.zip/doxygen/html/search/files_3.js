var searchData=
[
  ['leitor_2ec',['leitor.c',['../leitor_8c.html',1,'']]],
  ['leitor_2eh',['leitor.h',['../leitor_8h.html',1,'']]]
];

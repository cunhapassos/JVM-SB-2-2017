var searchData=
[
  ['it_5fexecutainstrucao',['IT_executaInstrucao',['../funcoes_8c.html#ac87aed2830eb9a54ab0eabeb687e3de2',1,'funcoes.c']]]
];

var indexSectionsWithContent =
{
  0: "acdefijlmoprstuv",
  1: "aceflmostv",
  2: "deflpsv",
  3: "aeilprv",
  4: "su",
  5: "acjt",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "defines",
  6: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Macros",
  6: "Modules"
};


var searchData=
[
  ['jbool',['JBOOL',['../structures_8h.html#a6a475777a59bcc4214f2393eed0cb0a9',1,'structures.h']]]
];

var searchData=
[
  ['localvariables',['LocalVariables',['../structLocalVariables.html',1,'']]]
];

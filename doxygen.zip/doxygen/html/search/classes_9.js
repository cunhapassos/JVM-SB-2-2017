var searchData=
[
  ['variable',['Variable',['../structVariable.html',1,'Variable'],['../unionvariable.html',1,'variable']]]
];

var searchData=
[
  ['retornartipostring',['retornarTipoString',['../virtualMachine_8c.html#a4cd04519d0a26ba3d3c272400fa0b1e2',1,'virtualMachine.c']]]
];

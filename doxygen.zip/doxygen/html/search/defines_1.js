var searchData=
[
  ['constant_5futf8',['CONSTANT_Utf8',['../structures_8h.html#afc46559a7d3f7baf519fc183c2fad2b4',1,'structures.h']]],
  ['constantvalue',['CONSTANTVALUE',['../structures_8h.html#a859aa5c67c5e43972131dbc0a18d5fcf',1,'structures.h']]]
];

#include "structures.h"
#include <stdio.h>
#include <stdlib.h>

int IT_executaInstrucao(ST_tpJVM *pJVM, ST_tpStackFrame **pFrame, ST_tpVariable **Retorno, ST_tpException_table *pExceptionTable, u1 **PC);

